import torch
import glob
import os
from torchvision import transforms
from PIL import Image
import numpy as np
from imgaug import augmenters as iaa
import imgaug as ia
from torch.utils.data.sampler import Sampler
import itertools

class Yuanyuan_loader(torch.utils.data.Dataset):

    def __init__(self, dataset_path, scale, mode='train'):
        super().__init__()
        self.mode = mode
        self.scale = scale
        if mode == 'train':
            self.img_path = dataset_path + '/train' + '/img'
        elif mode == 'val':
            self.img_path = dataset_path + '/val' + '/img'
        else:
            self.img_path = dataset_path + '/test' + '/img'
    
        self.image_lists, self.label_lists = self.read_list(self.img_path)
        # data augmentation
        self.aug = iaa.Sequential([
            iaa.Fliplr(0.5),  # 百分之五十的图片上下翻转
            iaa.SomeOf((0, 2), [
                iaa.Affine(
                    rotate=(-10, 10)),  # 旋转
            ], random_order=True)
        ])  # 对比度
        # resize
        self.resize_label = transforms.Resize(scale, Image.NEAREST)
        self.resize_img = transforms.Resize(scale, Image.BILINEAR)
        # resize
        self.to_gray = transforms.Grayscale()
        # normalization
        self.to_tensor = transforms.ToTensor()  # 将numpy的ndarray或PIL.Image读的图片转换成形状为(C,H, W)的Tensor格式，

    def __getitem__(self, index):
        # load image
        img = Image.open(self.image_lists[index]).convert('RGB')
        img = self.resize_img(img)
        img = np.array(img).astype(np.uint8)
        labels = self.label_lists[index]
        # load label
        if self.mode != 'test':
            label = Image.open(self.label_lists[index])
            label = self.resize_label(label)
            label = np.array(label).astype(np.uint8)
            label[label == 0] = 0
            label[label > 0] = 1
            # augment image and label
            if self.mode == 'train':
                seq_det = self.aug.to_deterministic()  # 得到一个确定的增强函数
                # 将图片转换为SegmentationMapOnImage类型
                segmap = ia.SegmentationMapsOnImage(label, shape=label.shape)
                # segmap2 = ia.SegmentationMapOnImage(label, shape=label.shape, nb_classes=4)
                # 将方法应用在原图像上
                img = seq_det.augment_image(img)
                # 将方法应用在分割标签上，并且转换成np类型
                label = seq_det.augment_segmentation_maps([segmap])[0]
                label = label.get_arr().astype(np.uint8)
            label = label.reshape((1, label.shape[0], label.shape[1]))
            label_img = torch.from_numpy(label.copy()).float()

            if self.mode == 'val' or self.mode == 'test':
                assert len(os.listdir(os.path.dirname(self.image_lists[index]))) == len(
                    os.listdir(os.path.dirname(labels)))
                img_num = len(os.listdir(os.path.dirname(labels)))
                labels = (label_img, img_num)  # val模式下labels返回一个元祖，[0]为tensor标签索引值h*w，[1]为cube中包含slice张数int值
            else:
                labels = label_img  # train模式下labels返回tensor标签索引值

        img = (img.transpose(2, 0, 1)-127.5) / 127.5
        img = torch.from_numpy(img.copy()).float()
        # test模式下labels返回label的路径列表
        return img, labels

    def __len__(self):
        return len(self.image_lists)

    def read_list(self, image_path):
        fold = sorted(os.listdir(image_path))
        img_list = []
        label_list = []

        fold_r = list(fold)
        for item in fold_r:
            cube_path = os.path.join(image_path, item)
            img_list.append(cube_path)
        label_list_TMP = [x.replace("img","mask") for x in img_list]
        label_list = [x.replace("jpg","png") for x in label_list_TMP]

        assert len(img_list) == len(label_list)
        print('Total {} image is:{}'.format(self.mode, len(img_list)))

        return img_list, label_list


if __name__ == '__main__':
    from torch.utils.data import DataLoader

    data = Slit_loader(r'../Datasets/OpticDiscSeg/data', (256, 256), mode='train')
    dataloader_train = DataLoader(
        data,
        batch_size=2,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
        drop_last=True
    )
#    for i, (img, label) in enumerate(dataloader_train):
#        print(img.shape)
#        #print(label.shape)  # train
#        print(label[0].shape)  # val
#        # print(label)  # test
#
#        print(i)
